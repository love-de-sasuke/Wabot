import { command, on } from '../lib/plugin.js'
import { LINK_REGEX } from '../lib/utils.js'
import { getGroupMeta, isAdminIn, findParticipant, invalidateGroup } from '../lib/group.js'
import { applyWarn } from '../lib/warns.js'
import { userOf } from '../lib/jid.js'

const ACTIONS = ['delete', 'warn', 'kick']

command({ name: 'antilink', desc: 'Block links: antilink on | off | action delete/warn/kick', type: 'group', group: true, admin: true, botAdmin: true }, async (m, args, ctx) => {
  const cfg = ctx.store.get('antilink', m.chat, { enabled: false, action: 'delete' })
  const [sub, value] = args.toLowerCase().split(/\s+/)

  if (sub === 'on' || sub === 'off') {
    cfg.enabled = sub === 'on'
  } else if (sub === 'action' && ACTIONS.includes(value)) {
    cfg.action = value
  } else if (sub) {
    return m.reply('Usage:\nantilink on\nantilink off\nantilink action delete|warn|kick')
  } else {
    return m.reply(`Anti-link is *${cfg.enabled ? 'ON' : 'OFF'}* (action: ${cfg.action}).`)
  }
  ctx.store.set('antilink', m.chat, cfg)
  await m.reply(`Anti-link is now *${cfg.enabled ? 'ON' : 'OFF'}* (action: ${cfg.action}).`)
})

on('message', async (m, ctx) => {
  if (!m.isGroup || m.fromMe || ctx.isOwner || !m.text) return
  const cfg = ctx.store.get('antilink', m.chat)
  if (!cfg?.enabled || !LINK_REGEX.test(m.text)) return

  const meta = await getGroupMeta(ctx.sock, m.chat)
  if (isAdminIn(meta, m.senderIds)) return // admins may post links
  if (!isAdminIn(meta, ctx.botIds)) return // can't act without admin rights

  await ctx.sock.sendMessage(m.chat, { delete: m.key })
  const target = findParticipant(meta, m.sender)?.id || m.sender
  const mention = '@' + userOf(target)

  if (cfg.action === 'kick') {
    await ctx.sock.groupParticipantsUpdate(m.chat, [target], 'remove')
    invalidateGroup(m.chat)
    await m.send({ text: `${mention} was removed for posting a link.`, mentions: [target] })
  } else if (cfg.action === 'warn') {
    const r = await applyWarn(ctx, m.chat, target)
    await m.send({
      text: r.kicked ? `${mention} reached ${r.limit} warnings and was removed.` : `${mention} ${ctx.config.ANTILINK_MSG} (${r.count}/${r.limit})`,
      mentions: [target],
    })
  } else {
    await m.send({ text: `${mention} ${ctx.config.ANTILINK_MSG}`, mentions: [target] })
  }
  return true
})
