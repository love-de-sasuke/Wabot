import { command, on } from '../lib/plugin.js'
import { getGroupMeta } from '../lib/group.js'
import { userOf } from '../lib/jid.js'

const DEFAULTS = {
  welcome: 'Welcome {user} to *{group}*!',
  goodbye: 'Goodbye {user}!',
}

function makeCommand(kind) {
  command({
    name: kind,
    desc: `${kind} message: ${kind} on | off | <text>. Placeholders: {user} {group} {count}`,
    type: 'group', group: true, admin: true,
  }, async (m, args, ctx) => {
    const cfg = ctx.store.get(kind, m.chat, { enabled: false, text: DEFAULTS[kind] })
    const lower = args.toLowerCase()
    if (lower === 'on' || lower === 'off') {
      cfg.enabled = lower === 'on'
    } else if (args) {
      cfg.text = args
      cfg.enabled = true
    } else {
      return m.reply(`${kind} is *${cfg.enabled ? 'ON' : 'OFF'}*.\n\nText:\n${cfg.text}`)
    }
    ctx.store.set(kind, m.chat, cfg)
    await m.reply(`${kind} is now *${cfg.enabled ? 'ON' : 'OFF'}*.\n\nText:\n${cfg.text}`)
  })
}
makeCommand('welcome')
makeCommand('goodbye')

on('groupParticipants', async ({ id, participants, action }, ctx) => {
  const kind = action === 'add' ? 'welcome' : action === 'remove' ? 'goodbye' : null
  if (!kind) return
  const cfg = ctx.store.get(kind, id)
  if (!cfg?.enabled) return

  const meta = await getGroupMeta(ctx.sock, id, true)
  for (const jid of participants) {
    const text = cfg.text
      .replaceAll('{user}', '@' + userOf(jid))
      .replaceAll('{group}', meta.subject)
      .replaceAll('{count}', String(meta.participants.length))
    await ctx.sock.sendMessage(id, { text, mentions: [jid] })
  }
})
