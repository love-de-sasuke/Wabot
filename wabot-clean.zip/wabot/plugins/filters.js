import { command, on } from '../lib/plugin.js'
import { escapeRegex } from '../lib/utils.js'

command({ name: 'filter', desc: 'Auto-reply to a word: filter hello:Hi there!', type: 'tools', admin: true }, async (m, args, ctx) => {
  const i = args.indexOf(':')
  if (i < 1 || !args.slice(i + 1).trim()) return m.reply('Usage: filter word:reply text')
  const word = args.slice(0, i).trim().toLowerCase()
  const reply = args.slice(i + 1).trim()
  const filters = ctx.store.get('filters', m.chat, {})
  filters[word] = reply
  ctx.store.set('filters', m.chat, filters)
  await m.reply(`Filter saved for "${word}".`)
})

command({ name: 'delfilter', alias: ['stop'], desc: 'Remove a filter: delfilter word', type: 'tools', admin: true }, async (m, args, ctx) => {
  const word = args.trim().toLowerCase()
  const filters = ctx.store.get('filters', m.chat, {})
  if (!(word in filters)) return m.reply(`No filter for "${word}".`)
  delete filters[word]
  ctx.store.set('filters', m.chat, filters)
  await m.reply(`Filter "${word}" removed.`)
})

command({ name: 'filters', desc: 'List filters in this chat.', type: 'tools' }, async (m, _args, ctx) => {
  const words = Object.keys(ctx.store.get('filters', m.chat, {}))
  await m.reply(words.length ? `*Filters*\n${words.map((w) => `- ${w}`).join('\n')}` : 'No filters set in this chat.')
})

on('message', async (m, ctx) => {
  if (m.fromMe || !m.text) return
  if ([...ctx.config.PREFIX].some((p) => m.text.startsWith(p))) return // commands are handled elsewhere
  const filters = ctx.store.get('filters', m.chat)
  if (!filters) return
  for (const [word, reply] of Object.entries(filters)) {
    if (new RegExp(`(^|\\W)${escapeRegex(word)}(\\W|$)`, 'i').test(m.text)) {
      await m.reply(reply)
      return
    }
  }
})
