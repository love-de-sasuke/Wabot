import os from 'node:os'
import { command, commands } from '../lib/plugin.js'
import { runtime, formatBytes } from '../lib/utils.js'
import { userOf } from '../lib/jid.js'

command({ name: 'ping', desc: 'Check how fast the bot responds.', type: 'info' }, async (m) => {
  const t0 = Date.now()
  await m.reply('*Ping!*')
  await m.reply(`*Pong!*\nLatency: ${Date.now() - t0}ms`)
})

command({ name: 'alive', desc: 'Check that the bot is running.', type: 'info' }, async (m, _args, ctx) => {
  const { config } = ctx
  await m.reply(
    `*${config.BOT_NAME}* is alive.\n\nVersion: ${config.VERSION}\nMode: ${config.MODE}\nUptime: ${runtime((Date.now() - ctx.startedAt) / 1000)}`
  )
})

command({ name: 'runtime', alias: ['uptime'], desc: 'How long the bot has been running.', type: 'info' }, async (m, _args, ctx) => {
  await m.reply(runtime((Date.now() - ctx.startedAt) / 1000))
})

command({ name: 'jid', desc: 'Show chat / user IDs (reply to or @mention someone for theirs).', type: 'whatsapp' }, async (m) => {
  const lines = [`Chat: ${m.chat}`, `You: ${m.senderIds.join(', ') || m.sender}`]
  if (m.quoted?.sender) lines.push(`Replied user: ${m.quoted.sender}`)
  if (m.mentions.length) lines.push(`Mentioned: ${m.mentions.join(', ')}`)
  await m.reply(lines.join('\n'))
})

command({ name: 'sysinfo', desc: 'Server and process information.', type: 'info', owner: true }, async (m, _args, ctx) => {
  const mem = process.memoryUsage()
  await m.reply(
    [
      `*System info*`,
      `Node: ${process.version}`,
      `Platform: ${os.platform()} ${os.arch()}`,
      `CPU cores: ${os.cpus().length}`,
      `RAM: ${formatBytes(os.totalmem() - os.freemem())} / ${formatBytes(os.totalmem())}`,
      `Bot memory: ${formatBytes(mem.rss)}`,
      `Bot uptime: ${runtime((Date.now() - ctx.startedAt) / 1000)}`,
    ].join('\n')
  )
})

command({ name: 'menu', alias: ['help', 'list'], desc: 'Show all commands, or details of one: menu <command>', type: 'info' }, async (m, args, ctx) => {
  const { config } = ctx
  const p = [...config.PREFIX][0]
  const query = args.toLowerCase().replace(/^[^a-z0-9]+/, '')

  if (query) {
    const c = commands.find((x) => x.name === query || x.alias.includes(query))
    if (!c) return m.reply(`Command "${query}" not found.`)
    const flags = [c.owner && 'owner only', c.admin && 'admins', c.group && 'groups only', c.botAdmin && 'bot must be admin'].filter(Boolean)
    return m.reply(
      [`*${p}${c.name}*`, c.desc || 'No description.', c.alias.length ? `Aliases: ${c.alias.map((a) => p + a).join(', ')}` : '', flags.length ? `Restrictions: ${flags.join(', ')}` : '']
        .filter(Boolean).join('\n')
    )
  }

  const groups = {}
  for (const c of commands) (groups[c.type] ||= []).push(p + c.name)

  let text = `*${config.BOT_NAME}*\n\n`
  text += `User: ${m.pushName || userOf(m.sender)}\nOwner: ${config.OWNER_NAME}\nMode: ${config.MODE}\n`
  text += `Uptime: ${runtime((Date.now() - ctx.startedAt) / 1000)}\nVersion: ${config.VERSION}\nCommands: ${commands.length}\n`
  for (const [type, names] of Object.entries(groups).sort()) {
    text += `\n*${type.toUpperCase()}*\n${names.sort().map((n) => `- ${n}`).join('\n')}\n`
  }
  text += `\nUse ${p}menu <command> for details.`
  await m.reply(text.trim())
})
