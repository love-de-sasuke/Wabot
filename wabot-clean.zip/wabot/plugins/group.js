import { command } from '../lib/plugin.js'
import { userOf } from '../lib/jid.js'
import { findParticipant, participantMatches, getGroupMeta, invalidateGroup } from '../lib/group.js'

const tag = (jid) => '@' + userOf(jid)

/** Members the command is aimed at: @mentions plus the sender of a replied-to message. The bot itself is skipped. */
export function targetsOf(m, ctx) {
  const wanted = [...m.mentions, m.quoted?.sender].filter(Boolean)
  const out = []
  for (const id of wanted) {
    const p = findParticipant(ctx.meta, id)
    if (!p || participantMatches(p, ctx.botIds) || out.includes(p.id)) continue
    out.push(p.id)
  }
  return out
}

const NEED_TARGET = 'Reply to a member or @mention them.'

command({ name: 'add', desc: 'Add people by number: add 919876543210, 9188...', type: 'group', group: true, admin: true, botAdmin: true }, async (m, args, ctx) => {
  const numbers = args.split(/[,\s]+/).map((s) => s.replace(/\D/g, '')).filter(Boolean)
  if (!numbers.length) return m.reply('Give me the numbers to add (with country code), separated by commas.')
  const found = await ctx.sock.onWhatsApp(...numbers.map((n) => `${n}@s.whatsapp.net`))
  const jids = (found || []).filter((f) => f.exists).map((f) => f.jid)
  if (!jids.length) return m.reply("Those numbers aren't on WhatsApp.")
  const results = await ctx.sock.groupParticipantsUpdate(m.chat, jids, 'add')
  invalidateGroup(m.chat)
  const text = {
    200: 'added to the group.',
    403: "couldn't be added directly (privacy settings), an invite may have been sent.",
    408: 'left recently, try again later.',
    401: 'has blocked the bot number.',
    409: 'is already in the group.',
  }
  const lines = (results || []).map((r) => `${tag(r.jid)} ${text[r.status] || `returned status ${r.status}`}`)
  await m.send({ text: lines.join('\n') || 'Done.', mentions: (results || []).map((r) => r.jid) }, { quoted: m.raw })
})

command({ name: 'kick', alias: ['remove'], desc: 'Remove a member. Reply to them or @mention them.', type: 'group', group: true, admin: true, botAdmin: true }, async (m, _args, ctx) => {
  const targets = targetsOf(m, ctx)
  if (!targets.length) return m.reply(NEED_TARGET)
  await ctx.sock.groupParticipantsUpdate(m.chat, targets, 'remove')
  invalidateGroup(m.chat)
  await m.send({ text: `${targets.map(tag).join(', ')} removed from the group.`, mentions: targets })
})

command({ name: 'promote', desc: 'Make a member an admin.', type: 'group', group: true, admin: true, botAdmin: true }, async (m, _args, ctx) => {
  const targets = targetsOf(m, ctx).filter((id) => !ctx.meta.participants.find((p) => p.id === id)?.admin)
  if (!targets.length) return m.reply(`${NEED_TARGET} (They may already be admins.)`)
  await ctx.sock.groupParticipantsUpdate(m.chat, targets, 'promote')
  invalidateGroup(m.chat)
  await m.send({ text: `${targets.map(tag).join(', ')} promoted to admin.`, mentions: targets })
})

command({ name: 'demote', desc: 'Remove admin rights from a member.', type: 'group', group: true, admin: true, botAdmin: true }, async (m, _args, ctx) => {
  const targets = targetsOf(m, ctx).filter((id) => ctx.meta.participants.find((p) => p.id === id)?.admin)
  if (!targets.length) return m.reply(`${NEED_TARGET} (They need to be admins.)`)
  await ctx.sock.groupParticipantsUpdate(m.chat, targets, 'demote')
  invalidateGroup(m.chat)
  await m.send({ text: `${targets.map(tag).join(', ')} is no longer an admin.`, mentions: targets })
})

command({ name: 'mute', alias: ['close'], desc: 'Only admins can send messages.', type: 'group', group: true, admin: true, botAdmin: true }, async (m, _args, ctx) => {
  await ctx.sock.groupSettingUpdate(m.chat, 'announcement')
  await m.reply('Group muted. Only admins can send messages.')
})

command({ name: 'unmute', alias: ['open'], desc: 'Let everyone send messages.', type: 'group', group: true, admin: true, botAdmin: true }, async (m, _args, ctx) => {
  await ctx.sock.groupSettingUpdate(m.chat, 'not_announcement')
  await m.reply('Group unmuted. Everyone can send messages.')
})

command({ name: 'tagall', desc: 'Mention every member: tagall <message>', type: 'group', group: true, admin: true }, async (m, args, ctx) => {
  const ids = ctx.meta.participants.map((p) => p.id)
  const text = `${args || 'Attention everyone!'}\n\n${ids.map((id) => `- ${tag(id)}`).join('\n')}`
  await m.send({ text, mentions: ids })
})

command({ name: 'tag', alias: ['hidetag'], desc: 'Notify everyone silently with your text or a replied message.', type: 'group', group: true, admin: true }, async (m, args, ctx) => {
  const text = args || m.quoted?.text
  if (!text) return m.reply('Give me some text, or reply to a text message.')
  await m.send({ text, mentions: ctx.meta.participants.map((p) => p.id) })
})

command({ name: 'link', alias: ['invite'], desc: 'Get the group invite link.', type: 'group', group: true, admin: true, botAdmin: true }, async (m, _args, ctx) => {
  const code = await ctx.sock.groupInviteCode(m.chat)
  await m.reply(`https://chat.whatsapp.com/${code}`)
})

command({ name: 'revoke', desc: 'Reset the group invite link.', type: 'group', group: true, admin: true, botAdmin: true }, async (m, _args, ctx) => {
  await ctx.sock.groupRevokeInvite(m.chat)
  await m.reply('Invite link reset. Use the link command to get the new one.')
})

command({ name: 'setname', desc: 'Change the group name.', type: 'group', group: true, admin: true, botAdmin: true }, async (m, args, ctx) => {
  if (!args) return m.reply('Give me the new group name.')
  await ctx.sock.groupUpdateSubject(m.chat, args)
  invalidateGroup(m.chat)
  await m.reply('Group name updated.')
})

command({ name: 'setdesc', desc: 'Change the group description.', type: 'group', group: true, admin: true, botAdmin: true }, async (m, args, ctx) => {
  if (!args) return m.reply('Give me the new description.')
  await ctx.sock.groupUpdateDescription(m.chat, args)
  invalidateGroup(m.chat)
  await m.reply('Group description updated.')
})

command({ name: 'ginfo', alias: ['groupinfo'], desc: 'Show information about this group.', type: 'group', group: true }, async (m, _args, ctx) => {
  const meta = await getGroupMeta(ctx.sock, m.chat, true)
  const admins = meta.participants.filter((p) => p.admin)
  await m.reply(
    [`*${meta.subject}*`, `Members: ${meta.participants.length}`, `Admins: ${admins.length}`, meta.desc ? `\n${meta.desc}` : ''].filter(Boolean).join('\n')
  )
})

command({ name: 'leave', desc: 'Make the bot leave this group.', type: 'group', group: true, owner: true }, async (m, _args, ctx) => {
  await m.reply('Goodbye!')
  await ctx.sock.groupLeave(m.chat)
})
