import { command } from '../lib/plugin.js'
import { userOf } from '../lib/jid.js'
import { applyWarn, getWarns, resetWarns } from '../lib/warns.js'
import { targetsOf } from './group.js'

const tag = (jid) => '@' + userOf(jid)

command({ name: 'warn', desc: 'Warn a member. At the limit they are removed. warn <reason> (reply or @mention)', type: 'group', group: true, admin: true, botAdmin: true }, async (m, args, ctx) => {
  const [target] = targetsOf(m, ctx)
  if (!target) return m.reply('Reply to a member or @mention them to warn.')
  const r = await applyWarn(ctx, m.chat, target)
  const reason = args ? `\nReason: ${args.replace(/@\d+/g, '').trim() || 'not given'}` : ''
  const text = r.kicked
    ? `${tag(target)} reached ${r.limit} warnings and was removed.${reason}`
    : `${tag(target)} has been warned (${r.count}/${r.limit}).${reason}`
  await m.send({ text, mentions: [target] })
})

command({ name: 'warnings', alias: ['warns'], desc: 'Show a member\'s warnings (reply or @mention).', type: 'group', group: true }, async (m, _args, ctx) => {
  const [target] = targetsOf(m, ctx)
  if (!target) return m.reply('Reply to a member or @mention them.')
  await m.send({ text: `${tag(target)} has ${getWarns(ctx.store, m.chat, target)}/${ctx.config.WARN_LIMIT} warnings.`, mentions: [target] })
})

command({ name: 'resetwarn', desc: 'Clear a member\'s warnings (reply or @mention).', type: 'group', group: true, admin: true }, async (m, _args, ctx) => {
  const [target] = targetsOf(m, ctx)
  if (!target) return m.reply('Reply to a member or @mention them.')
  resetWarns(ctx.store, m.chat, target)
  await m.send({ text: `Warnings cleared for ${tag(target)}.`, mentions: [target] })
})
