import fs from 'node:fs'

// Minimal .env loader (no dependency). Real environment variables win over .env.
function loadEnv(file = '.env') {
  if (!fs.existsSync(file)) return
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    if (!line.trim() || line.trim().startsWith('#')) continue
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/)
    if (!m) continue
    let value = m[2]
    if (/^(['"]).*\1$/.test(value)) value = value.slice(1, -1)
    if (process.env[m[1]] === undefined) process.env[m[1]] = value
  }
}
loadEnv()

const env = process.env
const bool = (v, def = false) =>
  v === undefined || v === '' ? def : ['true', '1', 'yes', 'on'].includes(String(v).toLowerCase())
const list = (v) => (v || '').split(',').map((s) => s.trim()).filter(Boolean)

const config = {
  VERSION: '1.0.0',
  PAIR_NUMBER: (env.PAIR_NUMBER || '').replace(/\D/g, ''),
  MODE: (env.MODE || 'private').toLowerCase() === 'public' ? 'public' : 'private',
  PREFIX: env.PREFIX || '.',
  BOT_NAME: env.BOT_NAME || 'Wabot',
  OWNER_NAME: env.OWNER_NAME || 'Owner',
  SUDO: list(env.SUDO),
  START_MSG: bool(env.START_MSG, true),
  ALWAYS_ONLINE: bool(env.ALWAYS_ONLINE),
  AUTO_STATUS_VIEW: bool(env.AUTO_STATUS_VIEW),
  REJECT_CALL: bool(env.REJECT_CALL),
  READ_MSG: bool(env.READ_MSG),
  LOG_MSG: bool(env.LOG_MSG, true),
  ERROR_MESSAGE: bool(env.ERROR_MESSAGE, true),
  WARN_LIMIT: Math.max(1, parseInt(env.WARN_LIMIT || '4', 10) || 4),
  SESSION_DIR: env.SESSION_DIR || './session',
  DATA_DIR: env.DATA_DIR || './data',
  DEBUG: bool(env.DEBUG),
  ANTILINK_MSG: env.ANTILINK_MSG || '_Links are not allowed in this group!_',
}

export default config
