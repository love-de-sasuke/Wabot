import path from 'node:path'
import { fileURLToPath } from 'node:url'
import config from './config.js'
import { Store } from './lib/store.js'
import { loadPlugins } from './lib/plugin.js'
import { connect } from './lib/client.js'
import { log } from './lib/logger.js'

const app = {
  config,
  store: new Store(path.join(config.DATA_DIR, 'bot.json')),
  startedAt: Date.now(),
  sock: null,
}

process.on('unhandledRejection', (e) => log.error('Unhandled rejection:', e))
process.on('uncaughtException', (e) => log.error('Uncaught exception:', e))

await loadPlugins(fileURLToPath(new URL('./plugins', import.meta.url)))
await connect(app)
