// Offline smoke test: feeds fake WhatsApp messages through the real handler with a mocked socket.
// Run: npm test
import os from 'node:os'
import path from 'node:path'
import fs from 'node:fs'
import assert from 'node:assert/strict'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'wabot-test-'))
process.env.DATA_DIR = tmp
process.env.SESSION_DIR = path.join(tmp, 'session')
process.env.MODE = 'public'
process.env.WARN_LIMIT = '2'
process.env.LOG_MSG = 'false'
process.env.SUDO = '5555'

const { default: config } = await import('../config.js')
const { Store } = await import('../lib/store.js')
const { loadPlugins, commands } = await import('../lib/plugin.js')
const { handleMessage, handleGroupParticipants, makeCtx } = await import('../lib/handler.js')

const GROUP = '120363000000000000@g.us'
const BOT_PN = '1111:7@s.whatsapp.net'
const BOT_LID = '9999:7@lid'
const ADMIN = '111@lid', MEMBER = '222@lid', MEMBER2 = '333@lid'

let sent = [], calls = []
const sock = {
  user: { id: BOT_PN, lid: BOT_LID },
  sendMessage: async (jid, content, opts) => { sent.push({ jid, content, opts }); return { key: { id: 'X' } } },
  readMessages: async () => {},
  onWhatsApp: async (...j) => j.map((jid) => ({ jid, exists: true })),
  groupMetadata: async (jid) => ({
    id: jid, subject: 'Test Group', desc: 'hello',
    participants: [
      { id: ADMIN, phoneNumber: '111@s.whatsapp.net', admin: 'admin' },
      { id: MEMBER, phoneNumber: '222@s.whatsapp.net', admin: null },
      { id: MEMBER2, phoneNumber: '333@s.whatsapp.net', admin: null },
      { id: '9999@lid', phoneNumber: '1111@s.whatsapp.net', admin: 'admin' }, // the bot
    ],
  }),
  groupParticipantsUpdate: async (jid, ids, action) => { calls.push({ fn: 'participants', ids, action }); return ids.map((id) => ({ status: '200', jid: id })) },
  groupSettingUpdate: async (jid, setting) => { calls.push({ fn: 'setting', setting }) },
  groupInviteCode: async () => 'INVITECODE',
}

const app = { config, store: new Store(path.join(tmp, 'bot.json')), startedAt: Date.now(), sock }
const ctx = makeCtx(app, sock)
await loadPlugins(path.resolve('plugins'))

let n = 0
function msg({ text, group = false, from = ADMIN, fromMe = false, mentions = [], quotedSender = null, dmChat = '777@lid' }) {
  const body = { text, contextInfo: {} }
  if (mentions.length) body.contextInfo.mentionedJid = mentions
  if (quotedSender) Object.assign(body.contextInfo, { quotedMessage: { conversation: 'old' }, stanzaId: 'Q1', participant: quotedSender })
  return {
    key: { remoteJid: group ? GROUP : dmChat, id: 'M' + ++n, fromMe, participant: group && !fromMe ? from : undefined },
    pushName: 'Tester',
    message: { extendedTextMessage: body },
  }
}
const run = async (raw) => { sent = []; calls = []; await handleMessage(ctx, raw) }
const lastText = () => { const c = sent.at(-1)?.content; return c?.text ?? '' }
let passed = 0
const check = async (name, fn) => { await fn(); passed++; console.log('  ok  ', name) }

console.log(`Loaded ${commands.length} commands`)

await check('owner (fromMe) can ping in a DM', async () => {
  await run(msg({ text: '.ping', fromMe: true }))
  assert.match(sent.map((s) => s.content.text).join('|'), /Pong/)
})

await check('private mode ignores non-owners silently', async () => {
  config.MODE = 'private'
  await run(msg({ text: '.ping' }))
  assert.equal(sent.length, 0)
  config.MODE = 'public'
})

await check('public mode answers non-owners', async () => {
  await run(msg({ text: '.alive' }))
  assert.match(lastText(), /is alive/)
})

await check('SUDO user (by number) counts as owner', async () => {
  await run(msg({ text: '.sysinfo', dmChat: '5555@s.whatsapp.net' }))
  assert.match(lastText(), /System info/)
})

await check('owner-only command refuses a normal user', async () => {
  await run(msg({ text: '.sysinfo' }))
  assert.match(lastText(), /owner only/)
})

await check('menu lists commands and details', async () => {
  await run(msg({ text: '.menu' }))
  assert.match(lastText(), /\.kick/)
  await run(msg({ text: '.menu kick' }))
  assert.match(lastText(), /Restrictions/)
})

await check('non-admin cannot kick', async () => {
  await run(msg({ text: '.kick', group: true, from: MEMBER, mentions: [MEMBER2] }))
  assert.match(lastText(), /Only group admins/)
  assert.equal(calls.length, 0)
})

await check('admin kicks by @mention (LID ids)', async () => {
  await run(msg({ text: '.kick', group: true, from: ADMIN, mentions: [MEMBER] }))
  assert.deepEqual(calls[0], { fn: 'participants', ids: [MEMBER], action: 'remove' })
})

await check('admin kicks by replying to a message', async () => {
  await run(msg({ text: '.kick', group: true, from: ADMIN, quotedSender: MEMBER2 }))
  assert.deepEqual(calls[0].ids, [MEMBER2])
})

await check('bot never targets itself', async () => {
  await run(msg({ text: '.kick', group: true, from: ADMIN, mentions: ['9999@lid'] }))
  assert.equal(calls.length, 0)
  assert.match(lastText(), /Reply to a member/)
})

await check('promote / mute / link work', async () => {
  await run(msg({ text: '.promote', group: true, from: ADMIN, mentions: [MEMBER] }))
  assert.equal(calls[0].action, 'promote')
  await run(msg({ text: '.mute', group: true, from: ADMIN }))
  assert.equal(calls[0].setting, 'announcement')
  await run(msg({ text: '.link', group: true, from: ADMIN }))
  assert.match(lastText(), /chat\.whatsapp\.com\/INVITECODE/)
})

await check('group-only command refused in DM', async () => {
  await run(msg({ text: '.tagall', fromMe: true }))
  assert.match(lastText(), /only works in groups/)
})

await check('tagall mentions everyone', async () => {
  await run(msg({ text: '.tagall hi all', group: true, from: ADMIN }))
  assert.equal(sent.at(-1).content.mentions.length, 4)
})

await check('warn counts then kicks at the limit (2)', async () => {
  await run(msg({ text: '.warn spam', group: true, from: ADMIN, mentions: [MEMBER] }))
  assert.match(lastText(), /warned \(1\/2\)/)
  await run(msg({ text: '.warn spam', group: true, from: ADMIN, mentions: [MEMBER] }))
  assert.match(lastText(), /removed/)
  assert.equal(calls[0].action, 'remove')
})

await check('antilink deletes links from members but not admins', async () => {
  await run(msg({ text: '.antilink on', group: true, from: ADMIN }))
  assert.match(lastText(), /ON/)
  await run(msg({ text: 'join https://spam.example', group: true, from: MEMBER }))
  assert.ok(sent.some((s) => s.content.delete), 'delete was sent')
  await run(msg({ text: 'see https://ok.example', group: true, from: ADMIN }))
  assert.ok(!sent.some((s) => s.content.delete), 'admin not deleted')
})

await check('filters auto-reply on whole word only', async () => {
  await run(msg({ text: '.filter hello:Hi there!', group: true, from: ADMIN }))
  await run(msg({ text: 'well hello friends', group: true, from: MEMBER }))
  assert.equal(lastText(), 'Hi there!')
  await run(msg({ text: 'othello', group: true, from: MEMBER }))
  assert.equal(sent.length, 0)
})

await check('welcome message fires on join', async () => {
  await run(msg({ text: '.welcome Hey {user}, welcome to {group}!', group: true, from: ADMIN }))
  sent = []
  await handleGroupParticipants(ctx, { id: GROUP, action: 'add', participants: [{ id: MEMBER }] })
  assert.match(sent[0].content.text, /Hey @222, welcome to Test Group!/)
})

await check('unknown command and plain text are ignored', async () => {
  await run(msg({ text: '.doesnotexist' }))
  await run(msg({ text: 'just chatting' }))
  assert.equal(sent.length, 0)
})

app.store.flush()
console.log(`\n${passed} checks passed`)
process.exit(0)
