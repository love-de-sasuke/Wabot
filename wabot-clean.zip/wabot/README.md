# Wabot

A clean, readable WhatsApp multi-device bot built on [Baileys](https://github.com/WhiskeySockets/Baileys).
Logs in with a **pairing code** (no QR scanning), uses a simple plugin system, and every file is plain,
readable JavaScript.

> **Use a spare number.** Baileys is an unofficial WhatsApp Web library. WhatsApp can restrict or
> ban numbers that run bots. Do not run this on an account you cannot afford to lose.

## Quick start

```bash
# Node.js 20+ required (22 recommended)
npm install
cp .env.example .env     # then edit it (set PAIR_NUMBER, SUDO, MODE...)
npm start
```

1. Put your number in `PAIR_NUMBER` (country code + number, digits only), or type it when asked.
2. The terminal prints an 8-character **pairing code**.
3. On the phone: WhatsApp > Settings > Linked devices > Link a device > *Link with phone number instead*, enter the code.
4. The session is saved in `./session`, so you only pair once. Back that folder up; deleting it means pairing again.

Run it in the background with pm2: `npm i -g pm2 && npm run pm2`.
Docker: `docker build -t wabot . && docker run -v $PWD/session:/app/session -v $PWD/data:/app/data --env-file .env wabot`

## Who can do what

| Setting | Effect |
|---|---|
| `MODE=private` | Only you (messages from your own account) and `SUDO` users can use commands. Everyone else is ignored. |
| `MODE=public` | Everyone can use normal commands. Owner and admin commands stay protected. |
| `SUDO=` | Extra owners. Numbers or LIDs, comma separated. Send `.jid` to the bot to see which ids an account uses. |

WhatsApp now identifies people by phone number **or** LID. The bot checks both, so admin and owner checks work either way.

## Commands (29)

| Category | Commands |
|---|---|
| info | `menu` `ping` `alive` `runtime` `sysinfo` |
| whatsapp | `jid` |
| group | `add` `kick` `promote` `demote` `mute` `unmute` `tagall` `tag` `link` `revoke` `setname` `setdesc` `ginfo` `leave` `warn` `warnings` `resetwarn` `antilink` `welcome` `goodbye` |
| tools | `filter` `delfilter` `filters` |

`menu <command>` shows details for any command. Default prefix is `.`, change it with `PREFIX`
(`PREFIX=.!/` accepts any of those characters).

## Adding your own command

Create `plugins/hello.js`:

```js
import { command } from '../lib/plugin.js'

command({ name: 'hello', desc: 'Say hi', type: 'fun' }, async (m, args, ctx) => {
  await m.reply(`Hi ${m.pushName}! You said: ${args || 'nothing'}`)
})
```

Restart the bot and it appears in `menu`. Command options: `owner`, `group`, `admin`, `botAdmin`, `alias`.
Useful message helpers: `m.reply()`, `m.send()`, `m.react()`, `m.quoted`, `m.mentions`, `m.isGroup`.
For passive features (like anti-link) use `on('message', ...)` or `on('groupParticipants', ...)`; see `plugins/antilink.js`.

## Project layout

```
index.js            entry point
config.js           reads .env
lib/client.js       Baileys connection, pairing code, reconnects
lib/handler.js      permission checks and command dispatch
lib/message.js      turns raw WhatsApp messages into a friendly object
lib/plugin.js       command() / on() registry and plugin loader
lib/group.js        group metadata cache, admin checks (LID-aware)
lib/store.js        small JSON key-value store (data/bot.json)
plugins/            one file per feature area
test/smoke.js       offline test with a mocked WhatsApp (npm test)
```

## Notes

- `package.json` pins Baileys `7.0.0-rc13`, the release-candidate line that npm currently serves as `latest`.
  If install fails or a newer one exists, run `npm install @whiskeysockets/baileys@latest` and re-test.
- Data (warnings, filters, greetings, anti-link settings) lives in `data/bot.json`. On hosts with ephemeral disks
  (Render, Koyeb free tiers) mount a volume for `session/` and `data/`, or you will need to pair again on every redeploy.
- `npm test` runs 18 offline checks against a mocked socket. It cannot test the live WhatsApp connection.

## Not ported yet

Sticker and media tools, text-to-speech, translate, remove.bg, Instagram downloader, automute, scheduled messages,
chatbot, fancy text, forward/delete helpers, and the Koyeb/Render deploy-control and plugin-installer commands from the original.
